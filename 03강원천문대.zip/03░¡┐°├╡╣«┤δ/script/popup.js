$(document).ready(function () {
  $(".btn-notice").click(function () {
    $(".notice").show();
    $(".gal").hide();
    $(".btn-notice").addClass("on");
    $(".btn-gal").removeClass("on");
  });

  $(".btn-gal").click(function () {
    $(".gal").show();
    $(".notice").hide();
    $(".btn-gal").addClass("on");
    $(".btn-notice").removeClass("on");
  });
  $(".notice").show();
  $(".gal").hide();
});

/////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function () {
  $(".open-modal").click(function () {
      $(".modal").fadeIn();
  });

  $(".close-modal").click(function () {
      $(".modal").fadeOut();
  });
});

/////////////////////////////////////////////////////////////////////////////////////////////

$(document).ready(function() {
  $(".gnb > li").mouseenter(function() {
    $(this).children(".sub").stop(true, true).slideDown();
  }); 

  $(".gnb > li").mouseleave(function() {
    $(this).children(".sub").stop(true, true).slideUp();
  });
});
